<?php
/**
 * Example of cached template usage.  Doesn't provide any speed increase since
 * we're not getting information from multiple files or a database, but it
 * introduces how the is_cached() method works.
 */

/**
 * First, include the template class.
 */
require_once('template.php');

/**
 * Here is the path to the templates.
 */
$path = './templates/';

/**
 * Define the template file we will be using for this page.
 */
$file = 'list.tpl.php';

/**
 * Pass a unique string for the template we want to cache.  The template
 * file name + the server REQUEST_URI is a good choice because:
 *    1. If you pass just the file name, re-used templates will all
 *       get the same cache.  This is not the desired behavior.
 *    2. If you just pass the REQUEST_URI, and if you are using multiple
 *       templates per page, the templates, even though they are completely
 *       different, will share a cache file (the cache file names are based
 *       on the passed-in cache_id.
 */
$cache_id = $file . $_SERVER['REQUEST_URI'];
$tpl = & new CachedTemplate($path, $cache_id, 900);

/**
 * Test to see if the template has been cached.  If it has, we don't
 * need to do any processing.  Thus, if you put a lot of db calls in
 * here (or file reads, or anything processor/disk/db intensive), you
 * will significantly cut the amount of time it takes for a page to
 * process.
 *
 * This should be read aloud as "If NOT Is_Cached"
 */
if(!($tpl->is_cached())) {
	$tpl->set('title', 'My Title');
	$tpl->set('intro', 'The intro paragraph.');
	$tpl->set('list', array('cat', 'dog', 'mouse'));
}

/**
 * Fetch the cached template.  It doesn't matter if is_cached() succeeds
 * or fails - fetch_cache() will fetch a cache if it exists, but if not,
 * it will parse and return the template as usual (and make a cache for
 * next time).
 */
echo $tpl->fetch_cache($file);
?>
