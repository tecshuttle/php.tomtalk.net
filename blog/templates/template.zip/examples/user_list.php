<?php
require_once('template.php');

/**
 * This variable holds the file system path to all our template files.
 */
$path = './templates/';

/**
 * Create a template object for the outer template and set its variables.
 */
$tpl = & new Template($path);
$tpl->set('title', 'User List');

/**
 * Create a template object for the inner template and set its variables.  The
 * fetch_user_list() function simply returns an array of users.
 */
$body = & new Template($path);
$body->set('user_list', fetch_user_list());

/**
 * Set the fetched template of the inner template to the 'body' variable in
 * the outer template.
 */
$tpl->set('body', $body->fetch('user_list.tpl.php'));

/**
 * Echo the results.
 */
echo $tpl->fetch('index.tpl.php');

/**
 * Just a function to simulate the retrieval of a user list.
 */
function fetch_user_list() {
	return array(
		array('id' => 1,
		      'name' => 'bob',
			  'email' => 'bob@mozilla.org',
			  'banned' => false),
		array('id' => 2,
		      'name' => 'judy',
			  'email' => 'judy@php.net',
			  'banned' => false),
		array('id' => 3,
		      'name' => 'joe',
			  'email' => 'joe@opera.com',
			  'banned' => false),
		array('id' => 4,
			  'name' => 'billy',
			  'email' => 'billy@wakeside.com',
			  'banned' => true),
		array('id' => 5,
		      'name' => 'eileen',
			  'email' => 'eileen@slashdot.org',
			  'banned' => false));
}
?>
