<table cellpadding="3" border="0" cellspacing="1">
	<tr>
		<td>Name</td>
		<td><?=$name;?></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><?=$email;?></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><?=$password;?></td>
	</tr>
</table>