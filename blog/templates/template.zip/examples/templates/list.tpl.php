<html>
	<head>
		<title><?=$title;?></title>
	</head>

	<body>
		<p><?=$intro;?></p>

		<ul>
			<?php foreach($list as $item) { ?>
				<li><?=$item;?>
			<?php } ?>
		</ul>

		<?=$body;?>

	</body>
</html>
