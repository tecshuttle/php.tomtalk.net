<html>
	<head>
		<title><?=$title;?></title>
	</head>

	<body>

		<h2><?=$title;?></h2>

<?=$body;?>

	</body>
</html>
