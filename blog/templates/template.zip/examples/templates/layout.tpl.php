<html>
	<head>
		<title><?=$title;?></title>
		<link href="style.css" rel="stylesheet" type="text/css" />
	</head>

	<body>
		<h1><?=$title;?></h1>

<?=$content;?>

	</body>
</html>