<table>
	<tr>
		<th>Id</th>
		<th>Name</th>
		<th>Email</th>
		<th>Banned</th>
	</tr>
<? foreach($user_list as $user): ?>
	<tr>
		<td align="center"><?=$user['id'];?></td>
		<td><?=$user['name'];?></td>
		<td><a href="mailto:<?=$user['email'];?>"><?=$user['email'];?></a></td>
		<td align="center"><?=($user['banned'] ? 'X' : '&nbsp;');?></td>
	</tr>
<? endforeach; ?>
</table>